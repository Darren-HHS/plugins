<?php

/**
 * Plugin name: Estatik Manage Users
 * Description: Estatik Users Profile & Register & Login.
 * Author: Estatik
 * Author URI: https://estatik.net
 * Version: 0.0.1
 */

if ( ! defined( 'DS' ) ) {
	define( 'DS', DIRECTORY_SEPARATOR );
}

define( 'EMU_FILE', __FILE__ );
define( 'EMU_PLUGIN_PATH', dirname( EMU_FILE ) );
define( 'EMU_PLUGIN_URL', plugin_dir_url( EMU_FILE ) );
define( 'EMU_PLUGIN_INCLUDES', dirname( EMU_FILE ) . DS . 'includes' . DS );

add_action( 'wp_enqueue_scripts', 'emu_assets' );

/**
 * @return void
 */
function emu_assets() {
	wp_enqueue_style( 'emu-front', EMU_PLUGIN_URL . 'public/css/style.css' );
	wp_enqueue_script( 'emu-front', EMU_PLUGIN_URL . 'public/js/front.js', array( 'jquery', 'clipboard' ) );
	wp_localize_script( 'emu-front', 'EMU', array(
		'settings' => array(
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
		),
		'tr' => array(
			'unknown_error' => __( 'Something was wrong. Please contact the support.', 'es' ),
		),
		'ajaxurl' => admin_url( 'admin-ajax.php' ),
		'nonce' => array(
			'saved_search' => wp_create_nonce( 'emu_remove_saved_search' ),
		),
	) );
}

add_action( 'init', 'emu_register_post_types' );

/**
 * @return void
 */
function emu_register_post_types() {
	$args = array(
		'public' => false,
		'show_in_menu' => false,
		'has_archive' => false,
		'supports' => array( 'title', 'author' ),
	);

	register_post_type( 'saved_search', $args );
}

include 'includes/class-wishlist.php';
include 'includes/entities/class-entity.php';
include 'includes/entities/class-user.php';
include 'includes/entities/class-post.php';
include 'includes/entities/class-saved-search.php';
include 'includes/auth/class-authentication.php';
include 'includes/auth/class-facebook-authentication.php';
include 'includes/auth/class-google-authentication.php';
include 'includes/class-flash-message.php';
include 'includes/class-auth-init.php';
include 'includes/functions.php';
include 'includes/ajax.php';
include 'includes/shortcodes/class-shortcodes.php';
