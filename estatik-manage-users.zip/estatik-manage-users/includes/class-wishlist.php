<?php

/**
 * Class Emu_Wishlist
 */
class Emu_Wishlist {

	/**
	 * @var integer
	 */
	protected $user_id;

	/**
	 * Emu_Wishlist_User constructor.
	 *
	 * @param $user_id
	 */
	public function __construct( $user_id ) {

		$this->user_id = $user_id;
	}

	/**
	 * @param $post_id
	 *
	 * @return bool|false|int
	 */
	public function add( $post_id ) {

		if ( ! $this->has( $post_id ) ) {
			return add_user_meta( $this->user_id, 'emu_wishlist_item', $post_id );
		}

		return true;
	}

	/**
	 * @param $post_id
	 *
	 * @return bool
	 */
	public function remove( $post_id ) {

		return delete_user_meta( $this->user_id, 'emu_wishlist_item', $post_id );
	}

	/**
	 * @return integer
	 */
	public function get_count() {

		return count( $this->get_items_ids() );
	}

	/**
	 * @param $post_id
	 *
	 * @return bool
	 */
	public function has( $post_id ) {

		$data = $this->get_items_ids();

		return in_array( $post_id, $data );
	}

	/**
	 * Return array of entities ids.
	 *
	 * @return array
	 */
	public function get_items_ids() {
		$data = get_user_meta( $this->user_id, 'emu_wishlist_item' );

		return $data ? $data : array();
	}
}