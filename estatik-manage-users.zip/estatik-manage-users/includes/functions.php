<?php

function emu_get_auth_networks_list() {
	return apply_filters( 'emu_get_auth_networks_list', array( 'facebook', 'google' ) );
}

/**
 * Return social network auth class instance.
 *
 * @param $network
 * @param array $config
 *
 * @return Emu_Authentication
 */
function emu_get_auth_instance( $network, $config = array() ) {
	$instance = null;

	switch ( $network ) {
		case 'facebook':
			$instance = new Emu_Facebook_Authentication( $config );
			break;

		case 'google':
			$instance = new Emu_Google_Authentication( $config );
			break;
	}

	return apply_filters( 'emu_get_auth_instance', $instance, $network, $config );
}

/**
 * Return flash messages container.
 *
 * @param $context
 *
 * @return Emu_Flash_Message
 */
function emu_get_flash_instance( $context ) {
	return apply_filters( 'emu_get_flash_instance', new Emu_Flash_Message( $context ) );
}

/**
 * Set flash message.
 *
 * @param $context string
 * @param $message string
 * @param $type string
 */
function emu_set_flash( $context, $message, $type = 'success' ) {
	$container = emu_get_flash_instance( $context );
	$container->set_message( $message, $type );
}

/**
 * Set flash message.
 *
 * @param $context string
 * @param $wp_error WP_Error
 */
function emu_set_wp_error_flash( $context, $wp_error ) {
	$container = emu_get_flash_instance( $context );
	$container->set_wp_error( $wp_error );
}

/**
 * Return plugin settings container.
 *
 * @return
 */
function emu_get_settings_container() {
	$ef_options = false;

	if ( function_exists( 'ept_estatik_framework_instance' ) ) {
		$ef = ept_estatik_framework_instance();

		if ( $ef ) {
			$ef_options = $ef_options = $ef->options();
		}
	}

	return $ef_options;
}

/**
 * Return estatik setting value.
 *
 * @param $name
 * @return mixed
 */
function ests( $name ) {
	$settings = emu_get_settings_container();

	if ( class_exists( 'Estatik_Framework_Options_Container' ) ) {
		return apply_filters( 'emu_get_setting', $settings->get( $name ), $name );
	} else {
		return false;
	}
}

/**
 * Recursive function for parse array args.
 *
 * @param $args
 * @param $defaults
 *
 * @return array
 */
function emu_parse_args( &$args, $defaults ) {
	$args     = (array) $args;
	$defaults = (array) $defaults;
	$result   = $defaults;

	foreach ( $args as $k => &$v ) {
		if ( is_array( $v ) && isset( $result[ $k ] ) ) {
			$result[ $k ] = emu_parse_args( $v, $result[ $k ] );
		} else {
			$result[ $k ] = $v;
		}
	}

	return $result;
}

if ( ! function_exists( 'emu_locate_template' ) ) {

	/**
	 * Return plugin template path.
	 *
	 * @param $template_path string
	 *
	 * @return string
	 */
	function emu_locate_template( $template_path ) {

		$find = array();
		$path = $template_path;
		$context = EMU_PLUGIN_PATH . DS . 'templates' . DS;
		$base = $template_path;

		$find[] = 'estatik/' . $template_path;
		$find[] = $context . $template_path;

		$template_path = locate_template( array_unique( $find ) );

		if ( ! $template_path ) {
			$template_path = $context . $base;
		}

		return apply_filters( 'emu_locate_template', $template_path, $path );
	}
}

if ( ! function_exists( 'emu_load_template' ) ) {

	/**
	 * Include template by provided path.
	 *
	 * @see emu_locate_template
	 *
	 * @param $template_path string
	 *    Template path.
	 *
	 * @param array $args
	 *    Template variables list.
	 */
	function emu_load_template( $template_path, $args = array() ) {

		global $posts, $post, $wp_did_header, $wp_query, $wp_rewrite, $wpdb, $wp_version, $wp, $id, $comment, $user_ID;
		$args = apply_filters( 'emu_template_args', $args, $template_path );
		extract( $args );

		include emu_locate_template( $template_path );
	}
}

/**
 * Return shortcode class name by shortcode name.
 *
 * @param $shortcode_name
 *
 * @return bool|string
 */
function emu_get_shortcode_classname( $shortcode_name ) {
	$class_name = ! empty( Emu_Shortcodemu_List::$_shortcodes[ $shortcode_name ] ) ?
		Emu_Shortcodemu_List::$_shortcodes[ $shortcode_name ] : false;

	return apply_filters( 'emu_get_shortcode_classname', $class_name, $shortcode_name );
}

/**
 * Return shortcode instance.
 *
 * @param $shortcode_name
 * @param array $attributes
 *
 * @return null|Emu_Shortcode
 */
function emu_get_shortcode_instance( $shortcode_name, $attributes = array() ) {
	$shortcode_classname = emu_get_shortcode_classname( $shortcode_name );
	$instance = null;

	if ( ! empty( $shortcode_classname ) ) {
		$instance = new $shortcode_classname( $attributes );
	}

	return apply_filters( 'emu_get_shortcode_instance', $instance, $shortcode_name, $attributes );
}

/**
 * Return field nonce.
 *
 * @param string $name
 *
 * @return null
 */
function emu_get_nonce( $name = '_wpnonce' ) {
	return isset( $_REQUEST[ $name ] ) ? $_REQUEST[ $name ] : null;
}

/**
 * Sanitize provided value.
 *
 * @param $var
 *
 * @return array|string
 */
function emu_clean( $var ) {
	if ( is_array( $var ) ) {
		return array_map( 'emu_clean', $var );
	} else {
		if ( is_scalar( $var ) ) {
			if ( emu_is_html( $var ) ) {
				return esc_attr( $var );
			}
		} else {
			return sanitize_text_field( $var );
		}

		return is_scalar( $var ) ? sanitize_text_field( $var ) : $var;
	}
}

/**
 * @param $string
 *
 * @return bool
 */
function emu_is_html( $string ) {
	return $string != strip_tags( $string );
}

/**
 * @param $context
 * @param null $default
 *
 * @param bool $is_popup
 *
 * @return string
 */
function emu_get_auth_page_uri( $context, $default = null, $is_popup = false ) {
	$url      = null;
	$default  = $default ? $default : home_url();
	$login_page_id = ests( 'login_page_id' );

	if ( in_array( $context, array( 'login-buttons', 'login-form', 'reset-form' ) ) ) {
		if ( $login_page_id && get_post_status( $login_page_id ) == 'publish' ) {
			$url = get_permalink( $login_page_id );
		}
	}

	$is_popup = $is_popup ? '#es-authentication-popup' : '';

	$url = $url ? $url : $default . $is_popup;

	return apply_filters( 'emu_get_auth_page_uri', add_query_arg( array( 'auth_item' => $context ), $url ) );
}

/**
 * @param $tabs
 *
 * @return mixed
 */
function emu_admin_config( $tabs ) {
	$tabs['tabs']['custom'] = array(
		'label' => __( 'Custom Settings', 'ept' ),
		'sections' => array(
			array(
				'title' => __( 'Custom Settings', 'ept' ),
				'fields' => array(
					'search_results_page_id',

					'is_buyers_register_enabled',
					'buyer_register_title',
					'buyer_register_subtitle',

					'is_login_form_enabled',

					'login_title',
					'login_subtitle',

					'login_page_id',
					'profile_page_id',

					'is_login_facebook_enabled',
					'facebook_app_id',
					'facebook_app_secret',

					'is_login_google_enabled',
					'google_client_key',
					'google_client_secret',
				),
			),
		),
	);

	return $tabs;
}
add_filter( 'ept_admin_config', 'emu_admin_config' );

function emu_theme_framework_config( $config ) {
	$config['options']['is_login_form_enabled'] = array(
		'label' => __( 'Enable Login Form', 'emu' ),
		'field_type' => 'input',
		'type' => 'checkbox',
		'name' => 'is_login_form_enabled',
		'value' => '1',
		'default_value' => 1,
	);

	$config['options']['login_title'] = array(
		'label' => __( 'Login title', 'emu' ),
		'field_type' => 'input',
		'type' => 'text',
		'name' => 'login_title',
		'default_value' => __( 'Sign in or register', 'emu' ),
	);

	$config['options']['login_subtitle'] = array(
		'label' => __( 'Login subtitle', 'emu' ),
		'field_type' => 'input',
		'type' => 'text',
		'name' => 'login_subtitle',
		'default_value' => __( 'to save your favourite homes and more', 'emu' ),
	);

	$config['options']['login_page_id'] = array(
		'label' => __( 'Login Page ID', 'emu' ),
		'field_type' => 'input',
		'type' => 'number',
		'name' => 'login_page_id',
	);

	$config['options']['is_buyers_register_enabled'] = array(
		'label' => __( 'Enable Register Form', 'emu' ),
		'field_type' => 'input',
		'type' => 'checkbox',
		'name' => 'is_buyers_register_enabled',
		'value' => '1',
		'default_value' => 1,
	);

	$config['options']['buyer_register_title'] = array(
		'label' => __( 'Register title', 'emu' ),
		'field_type' => 'input',
		'type' => 'text',
		'name' => 'buyer_register_title',
		'default_value' => __( 'Get started with your account', 'emu' ),
	);

	$config['options']['buyer_register_subtitle'] = array(
		'label' => __( 'Register subtitle', 'emu' ),
		'field_type' => 'input',
		'type' => 'text',
		'name' => 'buyer_register_subtitle',
		'default_value' => __( 'to save your favourite homes and more', 'emu' ),
	);

	$config['options']['profile_page_id'] = array(
		'label' => __( 'Profile Page ID', 'emu' ),
		'field_type' => 'input',
		'type' => 'number',
		'name' => 'profile_page_id',
	);

		$config['options']['is_login_facebook_enabled'] = array(
			'label' => __( 'Enable Facebook Auth', 'emu' ),
			'field_type' => 'input',
			'type' => 'checkbox',
			'name' => 'is_login_facebook_enabled',
			'value' => '1',
			'default_value' => '1',
		);

	$config['options']['facebook_app_id'] = array(
		'label' => __( 'Facebook App ID', 'emu' ),
		'field_type' => 'input',
		'type' => 'text',
		'name' => 'facebook_app_id',
		'value' => '',
	);

	$config['options']['facebook_app_secret'] = array(
		'label' => __( 'Facebook App Secret', 'emu' ),
		'field_type' => 'input',
		'type' => 'text',
		'name' => 'facebook_app_secret',
		'value' => '',
	);

	$config['options']['is_login_google_enabled'] = array(
		'label' => __( 'Enable Google Auth', 'emu' ),
		'field_type' => 'input',
		'type' => 'checkbox',
		'name' => 'is_login_google_enabled',
		'value' => '1',
		'default_value' => '1',
	);

	$config['options']['google_client_key'] = array(
		'label' => __( 'Google Client Key', 'emu' ),
		'field_type' => 'input',
		'type' => 'text',
		'name' => 'google_client_key',
		'value' => '',
	);

	$config['options']['google_client_secret'] = array(
		'label' => __( 'Google Client Secret', 'emu' ),
		'field_type' => 'input',
		'type' => 'text',
		'name' => 'google_client_secret',
		'value' => '',
	);

	$config['options']['search_results_page_id'] = array(
		'label' => __( 'Search results page ID', 'emu' ),
		'field_type' => 'input',
		'type' => 'number',
		'name' => 'search_results_page_id',
		'value' => '',
	);

	return $config;
}
add_filter( 'ept_framework_config', 'emu_theme_framework_config' );

/**
 * Return redirect url after success auth.
 *
 * @return mixed|void
 */
function emu_get_success_auth_redirect_url() {
	$profile_id = ests( 'profile_page_id' );

	if ( $profile_id  && get_post_status( $profile_id ) == 'publish' ) {
		$url = get_permalink( $profile_id );
	} else {
		$url = home_url();
	}

	return apply_filters( 'emu_get_success_auth_redirect_url', $url );
}

/**
 * Display or return active class via compare $a === $b
 *
 * @param $a
 * @param $b
 * @param string $active_class
 * @param bool $_echo
 *
 * @return string|void
 */
function emu_active_class( $a, $b, $active_class = 'emu-btn--active', $_echo = true ) {
	$result = $a === $b ? ' ' . $active_class : '';

	if ( $_echo ) {
		echo $result;
	} else {
		return $result;
	}
}

/**
 * @param $data
 *
 * @return string
 */
function emu_encode( $data ) {
	return base64_encode( build_query( $data ) );
}

/**
 * @param $data
 *
 * @return array|bool
 */
function emu_decode( $data ) {
	$decoded_base64 = base64_decode( $data );
	$decoded_json = wp_parse_args( $decoded_base64, true );

	return $decoded_json;
}

/**
 * @return mixed|void
 */
function emu_get_search_page_url() {
	$url = null;
	$search_results_page_id = ests( 'search_results_page_id' );

	if ( $search_results_page_id && get_post_status( $search_results_page_id ) == 'publish' ) {
		$url = get_permalink( $search_results_page_id );
	}
	return apply_filters( 'emu_get_search_page_url', $url );
}

/**
 * Return wishlist instance.
 *
 * @return Emu_Wishlist
 */
function emu_get_wishlist_instance() {
	$instance =  new Emu_Wishlist( get_current_user_id() );

	return apply_filters( 'emu_get_wishlist_instance', $instance );
}

/**
 * @param $array
 * @param null $callback
 * @param bool $remove_empty_arrays
 *
 * @return mixed
 */
function emu_array_filter_recursive( $array, $callback = null, $remove_empty_arrays = false ) {
	foreach ( $array as $key => & $value ) {
		if ( is_array( $value ) ) {
			$value = call_user_func_array( __FUNCTION__, array( $value, $callback, $remove_empty_arrays ) );
			if ( $remove_empty_arrays && ! (bool) $value ) {
				unset( $array[ $key ] );
			}
		} else {
			if ( ! is_null( $callback ) && is_callable( $callback ) && ! $callback( $value ) ) {
				unset( $array[ $key ] );
			} elseif ( ! (bool) $value ) {
				unset( $array[ $key ] );
			}
		}
	}
	unset( $value );

	return $array;
}