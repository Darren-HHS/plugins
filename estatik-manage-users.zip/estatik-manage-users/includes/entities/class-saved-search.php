<?php

/**
 * Class Emu_Saved_Search.
 *
 * @property $address string
 * @property $search_data string
 */
class Emu_Saved_Search extends Emu_Post {

	public static function field_labels() {
		return array(
			'p_Setting' => array(
				'label' => __( 'Setting' ),
				'values' => array(
					'1Setting1' => esc_html__( 'Beachfront', 'resales-marbella-wp-plugin' ),
					'1Setting2' => esc_html__( 'Frontline Golf', 'resales-marbella-wp-plugin' ),
					'1Setting3' => esc_html__( 'Town', 'resales-marbella-wp-plugin' ),
					'1Setting4' => esc_html__( 'Suburban', 'resales-marbella-wp-plugin' ),
					'1Setting5' => esc_html__( 'Country', 'resales-marbella-wp-plugin' ),
					'1Setting6' => esc_html__( 'Commercial Area', 'resales-marbella-wp-plugin' ),
					'1Setting7' => esc_html__( 'Beachside', 'resales-marbella-wp-plugin' ),
					'1Setting8' => esc_html__( 'Port', 'resales-marbella-wp-plugin' ),
					'1Setting9' => esc_html__( 'Village', 'resales-marbella-wp-plugin' ),
					'1Setting10' => esc_html__( 'Mountain Pueblo', 'resales-marbella-wp-plugin' ),
					'1Setting11' => esc_html__( 'Close To Golf', 'resales-marbella-wp-plugin' ),
					'1Setting12' => esc_html__( 'Close To Port', 'resales-marbella-wp-plugin' ),
					'1Setting13' => esc_html__( 'Close To Shops', 'resales-marbella-wp-plugin' ),
					'1Setting14' => esc_html__( 'Close To Sea', 'resales-marbella-wp-plugin' ),
					'1Setting15' => esc_html__( 'Close To Town', 'resales-marbella-wp-plugin' ),
					'1Setting16' => esc_html__( 'Close To Schools', 'resales-marbella-wp-plugin' ),
					'1Setting17' => esc_html__( 'Close To Skiing', 'resales-marbella-wp-plugin' ),
					'1Setting18' => esc_html__( 'Close To Forest', 'resales-marbella-wp-plugin' ),
					'1Setting19' => esc_html__( 'Marina', 'resales-marbella-wp-plugin' ),
					'1Setting20' => esc_html__( 'Close To Marina', 'resales-marbella-wp-plugin' ),
					'1Setting21' => esc_html__( 'Urbanisation', 'resales-marbella-wp-plugin' ),
					'1Setting22' => esc_html__( 'Front Line Beach Complex', 'resales-marbella-wp-plugin' ),
				)
			),

			'p_Orientation' => array(
				'label' => __( 'Orientation' ),
				'values' => array(
					'1Orientation1' => esc_html__( 'North Facing', 'resales-marbella-wp-plugin' ),
					'1Orientation2' => esc_html__( 'North East Orientation', 'resales-marbella-wp-plugin' ),
					'1Orientation3' => esc_html__( 'East Facing', 'resales-marbella-wp-plugin' ),
					'1Orientation4' => esc_html__( 'South East Orientation', 'resales-marbella-wp-plugin' ),
					'1Orientation5' => esc_html__( 'South Facing', 'resales-marbella-wp-plugin' ),
					'1Orientation6' => esc_html__( 'South West Orientation', 'resales-marbella-wp-plugin' ),
					'1Orientation7' => esc_html__( 'West Facing', 'resales-marbella-wp-plugin' ),
					'1Orientation8' => esc_html__( 'North West Orientation', 'resales-marbella-wp-plugin' ),
				)
			),

			'p_Condition' => array(
				'label' => __( 'Condition' ),
				'values' => array(
					'1Condition1' => esc_html__( 'Excellent Condition', 'resales-marbella-wp-plugin' ),
					'1Condition2' => esc_html__( 'Good Condition', 'resales-marbella-wp-plugin' ),
					'1Condition3' => esc_html__( 'Fair Condition', 'resales-marbella-wp-plugin' ),
					'1Condition4' => esc_html__( 'Renovation Required', 'resales-marbella-wp-plugin' ),
					'1Condition5' => esc_html__( 'Recently Renovated', 'resales-marbella-wp-plugin' ),
					'1Condition6' => esc_html__( 'Recently Refurbished', 'resales-marbella-wp-plugin' ),
					'1Condition7' => esc_html__( 'Restoration Required', 'resales-marbella-wp-plugin' ),
					'1Condition8' => esc_html__( 'New Construction', 'resales-marbella-wp-plugin' ),
				)
			),

			'p_Pool' => array(
				'label' => __( 'Pool' ),
				'values' => array(
					'1Pool1' => esc_html__( 'Communal Pool', 'resales-marbella-wp-plugin' ),
					'1Pool2' => esc_html__( 'Private Pool', 'resales-marbella-wp-plugin' ),
					'1Pool3' => esc_html__( 'Indoor Pool', 'resales-marbella-wp-plugin' ),
					'1Pool4' => esc_html__( 'Heated Pool', 'resales-marbella-wp-plugin' ),
					'1Pool5' => esc_html__( 'Room For Pool', 'resales-marbella-wp-plugin' ),
					'1Pool6' => esc_html__( 'Childrens Pool', 'resales-marbella-wp-plugin' ),
				)
			),

			'p_Climate' => array(
				'label' => __( 'Climate' ),
				'values' => array(
					'1Climate Control1' => esc_html__( 'Air Conditioning', 'resales-marbella-wp-plugin' ),
					'1Climate Control2' => esc_html__( 'Pre Installed A/C', 'resales-marbella-wp-plugin' ),
					'1Climate Control3' => esc_html__( 'Hot A/C', 'resales-marbella-wp-plugin' ),
					'1Climate Control4' => esc_html__( 'Cold A/C', 'resales-marbella-wp-plugin' ),
					'1Climate Control5' => esc_html__( 'Central Heating', 'resales-marbella-wp-plugin' ),
					'1Climate Control6' => esc_html__( 'Fireplace', 'resales-marbella-wp-plugin' ),
					'1Climate Control7' => esc_html__( 'U/F Heating', 'resales-marbella-wp-plugin' ),
					'1Climate Control8' => esc_html__( 'U/F/H Bathrooms', 'resales-marbella-wp-plugin' ),
				)
			),

			'p_Views' => array(
				'label' => __( 'Views' ),
				'values' => array(
					'1Views1' => esc_html__( 'Sea Views', 'resales-marbella-wp-plugin' ),
					'1Views2' => esc_html__( 'Mountain Views', 'resales-marbella-wp-plugin' ),
					'1Views3' => esc_html__( 'Golf Views', 'resales-marbella-wp-plugin' ),
					'1Views4' => esc_html__( 'Beach Views', 'resales-marbella-wp-plugin' ),
					'1Views5' => esc_html__( 'Port Views', 'resales-marbella-wp-plugin' ),
					'1Views6' => esc_html__( 'Country Views', 'resales-marbella-wp-plugin' ),
					'1Views7' => esc_html__( 'Panoramic Views', 'resales-marbella-wp-plugin' ),
					'1Views8' => esc_html__( 'Garden Views', 'resales-marbella-wp-plugin' ),
					'1Views9' => esc_html__( 'Pool Views', 'resales-marbella-wp-plugin' ),
					'1Views10' => esc_html__( 'Courtyard Views', 'resales-marbella-wp-plugin' ),
					'1Views11' => esc_html__( 'Lake Views', 'resales-marbella-wp-plugin' ),
					'1Views12' => esc_html__( 'Urban Views', 'resales-marbella-wp-plugin' ),
					'1Views13' => esc_html__( 'Ski Views', 'resales-marbella-wp-plugin' ),
					'1Views14' => esc_html__( 'Forest Views', 'resales-marbella-wp-plugin' ),
					'1Views15' => esc_html__( 'Street Views', 'resales-marbella-wp-plugin' ),
				)
			),

			'p_Features' => array(
				'label' => esc_html__( 'Features', 'resales-marbella-wp-plugin' ),
				'values' => array(
					'1Features1' => esc_html__( 'Covered Terrace', 'resales-marbella-wp-plugin' ),
					'1Features2' => esc_html__( 'Lift', 'resales-marbella-wp-plugin' ),
					'1Features3' => esc_html__( 'Fitted Wardrobes', 'resales-marbella-wp-plugin' ),
					'1Features4' => esc_html__( 'Near Transport', 'resales-marbella-wp-plugin' ),
					'1Features5' => esc_html__( 'Private Terrace', 'resales-marbella-wp-plugin' ),
					'1Features6' => esc_html__( 'Solarium', 'resales-marbella-wp-plugin' ),
					'1Features7' => esc_html__( 'Satellite TV', 'resales-marbella-wp-plugin' ),
					'1Features8' => esc_html__( 'ADSL / WIFI', 'resales-marbella-wp-plugin' ),
					'1Features9' => esc_html__( 'Gym', 'resales-marbella-wp-plugin' ),
					'1Features10' => esc_html__( 'Sauna', 'resales-marbella-wp-plugin' ),
					'1Features11' => esc_html__( 'Games Room', 'resales-marbella-wp-plugin' ),
					'1Features12' => esc_html__( 'Paddle Tennis', 'resales-marbella-wp-plugin' ),
					'1Features13' => esc_html__( 'Tennis Court', 'resales-marbella-wp-plugin' ),
					'1Features14' => esc_html__( 'Guest Apartment', 'resales-marbella-wp-plugin' ),
					'1Features15' => esc_html__( 'Guest House', 'resales-marbella-wp-plugin' ),
					'1Features16' => esc_html__( 'Storage Room', 'resales-marbella-wp-plugin' ),
					'1Features17' => esc_html__( 'Utility Room', 'resales-marbella-wp-plugin' ),
					'1Features18' => esc_html__( 'Ensuite Bathroom', 'resales-marbella-wp-plugin' ),
					'1Features19' => esc_html__( 'Wood Flooring', 'resales-marbella-wp-plugin' ),
					'1Features20' => esc_html__( 'Disabled Access', 'resales-marbella-wp-plugin' ),
					'1Features22' => esc_html__( 'Marble Flooring', 'resales-marbella-wp-plugin' ),
					'1Features23' => esc_html__( 'Jacuzzi', 'resales-marbella-wp-plugin' ),
					'1Features24' => esc_html__( 'Bar', 'resales-marbella-wp-plugin' ),
					'1Features25' => esc_html__( 'Barbeque', 'resales-marbella-wp-plugin' ),
					'1Features27' => esc_html__( 'Double Glazing', 'resales-marbella-wp-plugin' ),
					'1Features28' => esc_html__( 'Domotics', 'resales-marbella-wp-plugin' ),
					'1Features29' => esc_html__( '24 Hour Reception', 'resales-marbella-wp-plugin' ),
					'1Features30' => esc_html__( 'Restaurant On Site', 'resales-marbella-wp-plugin' ),
					'1Features31' => esc_html__( 'Car Hire Facility', 'resales-marbella-wp-plugin' ),
					'1Features32' => esc_html__( 'Courtesy Bus', 'resales-marbella-wp-plugin' ),
					'1Features33' => esc_html__( 'Day Care', 'resales-marbella-wp-plugin' ),
					'1Features34' => esc_html__( 'Near Mosque', 'resales-marbella-wp-plugin' ),
					'1Features35' => esc_html__( 'Staff Accommodation', 'resales-marbella-wp-plugin' ),
					'1Features36' => esc_html__( 'Stables', 'resales-marbella-wp-plugin' ),
					'1Features37' => esc_html__( 'Near Church', 'resales-marbella-wp-plugin' ),
					'1Features38' => esc_html__( 'Basement', 'resales-marbella-wp-plugin' ),
					'1Features39' => esc_html__( 'Fiber Optic', 'resales-marbella-wp-plugin' ),
				)
			),
			'p_Furniture' => array(
				'label' => esc_html__( 'Furniture', 'resales-marbella-wp-plugin' ),
				'values' => array(
					'1Furniture1' => esc_html__( 'Fully Furnished', 'resales-marbella-wp-plugin' ),
					'1Furniture2' => esc_html__( 'Part Furnished', 'resales-marbella-wp-plugin' ),
					'1Furniture3' => esc_html__( 'Not Furnished', 'resales-marbella-wp-plugin' ),
					'1Furniture4' => esc_html__( 'Optional Furniture', 'resales-marbella-wp-plugin' ),
				)
			),
			'p_Kitchen' => array(
				'label' => esc_html__( 'Kitchen', 'resales-marbella-wp-plugin' ),
				'values' => array(
					'1Kitchen1' => esc_html__( 'Fully Fitted Kitchen', 'resales-marbella-wp-plugin' ),
					'1Kitchen2' => esc_html__( 'Partially Fitted Kitchen', 'resales-marbella-wp-plugin' ),
					'1Kitchen3' => esc_html__( 'Not Fitted Kitchen', 'resales-marbella-wp-plugin' ),
					'1Kitchen4' => esc_html__( 'Kitchen-Lounge', 'resales-marbella-wp-plugin' ),
				)
			),
			'p_Garden' => array(
				'label' => esc_html__( 'Garden', 'resales-marbella-wp-plugin' ),
				'values' => array(
					'1Garden1' => esc_html__( 'Communal Garden', 'resales-marbella-wp-plugin' ),
					'1Garden2' => esc_html__( 'Private Garden', 'resales-marbella-wp-plugin' ),
					'1Garden3' => esc_html__( 'Landscaped Garden', 'resales-marbella-wp-plugin' ),
					'1Garden4' => esc_html__( 'Easy Maintenance Garden', 'resales-marbella-wp-plugin' ),
				)
			),
			'p_Security' => array(
				'label' => esc_html__( 'Security', 'resales-marbella-wp-plugin' ),
				'values' => array(
					'1Security1' => esc_html__( 'Gated Complex', 'resales-marbella-wp-plugin' ),
					'1Security2' => esc_html__( 'Electric Blinds', 'resales-marbella-wp-plugin' ),
					'1Security3' => esc_html__( 'Entry Phone', 'resales-marbella-wp-plugin' ),
					'1Security4' => esc_html__( 'Alarm System', 'resales-marbella-wp-plugin' ),
					'1Security5' => esc_html__( '24 Hour Security', 'resales-marbella-wp-plugin' ),
					'1Security6' => esc_html__( 'Safe', 'resales-marbella-wp-plugin' ),
				)
			),

			'p_Parking' => array(
				'label' => esc_html__( 'Parking', 'resales-marbella-wp-plugin' ),
				'values' => array(
					'1Parking1' => esc_html__( 'Underground Parking', 'resales-marbella-wp-plugin' ),
					'1Parking2' => esc_html__( 'Garage', 'resales-marbella-wp-plugin' ),
					'1Parking3' => esc_html__( 'Covered Parking', 'resales-marbella-wp-plugin' ),
					'1Parking4' => esc_html__( 'Open Parking', 'resales-marbella-wp-plugin' ),
					'1Parking5' => esc_html__( 'Street Parking', 'resales-marbella-wp-plugin' ),
					'1Parking6' => esc_html__( 'Multiple Parking Spaces', 'resales-marbella-wp-plugin' ),
					'1Parking7' => esc_html__( 'Communal Parking', 'resales-marbella-wp-plugin' ),
					'1Parking8' => esc_html__( 'Private Parking', 'resales-marbella-wp-plugin' ),
				)
			),
			'p_Utilities' => array(
				'label' => esc_html__( 'Unilities', 'resales-marbella-wp-plugin' ),
				'values' => array(
					'1Utilities1' => esc_html__( 'Electricity', 'resales-marbella-wp-plugin' ),
					'1Utilities2' => esc_html__( 'Drinkable Water', 'resales-marbella-wp-plugin' ),
					'1Utilities3' => esc_html__( 'Telephone', 'resales-marbella-wp-plugin' ),
					'1Utilities4' => esc_html__( 'Gas', 'resales-marbella-wp-plugin' ),
				)
			),
			'p_Category' => array(
				'label' => esc_html__( 'Category', 'resales-marbella-wp-plugin' ),
				'values' => array(
					'1Category1' => esc_html__( 'Bargain', 'resales-marbella-wp-plugin' ),
					'1Category2' => esc_html__( 'Beachfront', 'resales-marbella-wp-plugin' ),
					'1Category3' => esc_html__( 'Cheap', 'resales-marbella-wp-plugin' ),
					'1Category4' => esc_html__( 'Distressed', 'resales-marbella-wp-plugin' ),
					'1Category5' => esc_html__( 'Golf', 'resales-marbella-wp-plugin' ),
					'1Category6' => esc_html__( 'Holiday Homes', 'resales-marbella-wp-plugin' ),
					'1Category7' => esc_html__( 'Investment', 'resales-marbella-wp-plugin' ),
					'1Category8' => esc_html__( 'Luxury', 'resales-marbella-wp-plugin' ),
					'1Category9' => esc_html__( 'Off Plan', 'resales-marbella-wp-plugin' ),
					'1Category10' => esc_html__( 'Reduced', 'resales-marbella-wp-plugin' ),
					'1Category11' => esc_html__( 'Repossession', 'resales-marbella-wp-plugin' ),
					'1Category12' => esc_html__( 'Resale', 'resales-marbella-wp-plugin' ),
					'1Category13' => esc_html__( 'CondiWith Planning PermissiontWith Planning Permissionion', 'resales-marbella-wp-plugin' ),
					'1Category14' => esc_html__( 'Contemporary', 'resales-marbella-wp-plugin' ),
					'1Category15' => esc_html__( 'New Development', 'resales-marbella-wp-plugin' ),
				)
			),

			'p_PV' => array(
				'label' => __( 'Plots and Ventures' ),
				'values' => array(
					'2Plots and Ventures1' => esc_html__( 'Plot', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures2' => esc_html__( 'With License', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures3' => esc_html__( 'Without License', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures4' => esc_html__( 'Residential', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures5' => esc_html__( 'Commercial', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures6' => esc_html__( 'Project', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures7' => esc_html__( 'Rustic', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures8' => esc_html__( 'Urbanised', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures9' => esc_html__( 'Fully Approved', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures10' => esc_html__( 'Not Started', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures12' => esc_html__( 'Fully Complete', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures13' => esc_html__( 'Hotel', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures14' => esc_html__( 'Hostel', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures15' => esc_html__( 'ed and Breakfast', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures16' => esc_html__( 'Bar', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures17' => esc_html__( 'Restaurant', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures18' => esc_html__( 'Shop', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures19' => esc_html__( 'Office', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures20' => esc_html__( 'Apartments', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures21' => esc_html__( 'Town Houses', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures22' => esc_html__( 'Villas', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures23' => esc_html__( 'Nursing Home', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures24' => esc_html__( 'Hospital', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures25' => esc_html__( 'School', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures26' => esc_html__( 'Sports Centre', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures27' => esc_html__( 'Equestrian Centre', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures28' => esc_html__( 'Golf Course', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures29' => esc_html__( 'Garage Space', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures30' => esc_html__( 'Warehouse', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures31' => esc_html__( 'Leasehold', 'resales-marbella-wp-plugin' ),
					'2Plots and Ventures32' => esc_html__( 'Gymnasium', 'resales-marbella-wp-plugin' ),
				),
			),

			'p_Rentals' => array(
				'label' => esc_html__( 'Rentals', 'resales-marbella-wp-plugin' ),
				'values' => array(
					'3Rentals1' => esc_html__( 'Bank Guarantee Required', 'resales-marbella-wp-plugin' ),
					'3Rentals2' => esc_html__( 'References Required', 'resales-marbella-wp-plugin' ),
					'3Rentals3' => esc_html__( 'Smoking Allowed', 'resales-marbella-wp-plugin' ),
					'3Rentals4' => esc_html__( 'Pets Allowed', 'resales-marbella-wp-plugin' ),
				)
			),
		);
	}

	public static $types;

	public static function get_types() {
		if ( ! static::$types ) {
			$roh_api_key = esc_attr( get_option( 'roh-api-key' ) );
			$roh_client_id = esc_attr( get_option( 'roh-client-id' ) );

			$url = "https://webapi.resales-online.com/V6/SearchPropertyTypes";
			$data = array(
				"p1" => $roh_client_id,
				"p2" => $roh_api_key,
				"P_ApiId" => esc_attr( get_option( 'roh-filter-id-1' ) )
			);
			$query_url = sprintf( "%s?%s", $url, http_build_query( $data ) );
			header( 'Content-type: application/json' );
			$api = file_get_contents( $query_url );
			$api_resp = json_decode( $api );
			$PropLoc = $api_resp->PropertyTypes->PropertyType;
			foreach ( $PropLoc as $match ) {
				static::$types[$match->OptionValue] = $match->Type;

				if ( ! empty( $match->SubType ) ) {
					foreach ( $match->SubType as $subtype ) {
						static::$types[$subtype->OptionValue] = $subtype->Type;
					}
				}
			}
		}

		return static::$types;
	}

    /**
     * @return string
     */
    public function get_entity_prefix() {
        return 'emu_saved_search_';
    }

    /**
     * @return mixed
     */
    public static function get_post_type_name() {
        return 'saved_search';
    }

    /**
     * Return entity field value.
     *
     * @param $name
     *
     * @return mixed
     */
    public function __get( $name ) {
        $field = static::get_field_info( $name );
        $value = null;

        if ( ! empty( $field ) ) {
            if ( ! empty( $field['system'] ) ) {
                $value = $this->get_wp_entity()->{$name};
            }
        } else {
            $value = $this->get_field_value( $name );
        }

        return apply_filters( "emu_get_" . static::get_entity_name() . "_field_value", $value, $name, $this );
    }

    /**
     * @return bool|false|int|string
     */
    public function get_title() {
         $entity = $this->get_wp_entity();

         if ( empty( $entity->post_title ) ) {
             return get_the_time( 'l, F jS, H:i' );
         } else {
             return get_the_title( $entity->ID );
         }
    }

    /**
     * Return search query readable string.
     *
     * @return string
     */
    public function get_formatted_query_string() {
        $data = $this->search_data;
        $result = array();

        if ( ! empty( $data ) ) {
            foreach ( $data as $field => $value ) {
	            if ( $field == 'p_PropertyListing' ) {
		            if ( $value[0] == 11357 ) {
			            $value = 'Sales';
		            }

		            if ( $value[0] == 3172 ) {
						$value = 'Short Term Rentals';
		            }

		            if ( $value[0] == 3175 ) {
						$value = 'Long Term Rentals';
		            }
	            }

            	if ( ! $value ) continue;

            	$labels = static::field_labels();

            	if ( $field == 'p_Views' && $value == 1 ) continue;

            	if ( ! empty( $labels[$field] ) ) {
            		$result[] = $labels[$field]['label'] . ': ' .$labels[$field]['values'][$value];
	            }

            	if ( $field == 'virtualtours' ) {
		            $result[] =  "Virtual Tour: Yes";
	            }

				if ( $field == 'baths2' ) $result[] =  "Bathrooms: $value";

	            if ( $field == 'p_PropertyListing' ) {
	            	$result[] = 'Listings: ' . $value;
	            }

	            if ( $field == 'ptypei' ) {
	            	$types = static::get_types();
	            	$labels = array();
	            	foreach ( $value as $type_value ) {
	            		$labels[] = $types[ $type_value ];
		            }
					if ( $labels ) {
						$result[] = "Property type: " . implode( ', ', $labels );
					}
	            }

				if ( $field == 'plocs' ) {
					$result[] = "Location: " . implode( ', ', $value );
				}

				if ( $field == 'beds2' ) $result[] =  "Bedrooms: $value";
				if ( $field == 'price2_min' ) {
					$value = number_format( $value );
					$value = '&euro;' . $value;
					$result[] = "Price min: $value";
				}

				if ( $field == 'price2_max' ) {
					$value = number_format( $value );
					$value = '&euro;' . $value;
					$result[] =  "Price max: $value";
				}
            }
        }

        return apply_filters( 'emu_saved_search_get_formatted_query_string', implode( ' | ', $result ), $this );
    }

    /**
     * Save search args.
     *
     * @param $data
     */
    public function save_fields( $data ) {
        $entity = static::get_entity_name();

        if ( ! empty( $data ) ) {
            foreach ( $data as $field => $value ) {
                $this->save_field_value( $field, $value );
            }

            $this->save_field_value( 'search_data', $data );
        }

        do_action( "emu_{$entity}_after_save_fields", $data, $this );
    }
}
