<?php

/**
 * Class Emu_Post.
 */
abstract class Emu_Post extends Emu_Entity
{
	/**
	 * @inheritdoc
	 */
	public function get_wp_entity() {

		if ( empty( $this->_wp_entity ) ) {
			$this->_wp_entity = get_post( $this->get_id() );
		}

		return $this->_wp_entity;
	}

	/**
	 * @inheritdoc
	 */
	public function get_field_value( $field ) {
		$entity = static::get_entity_name();
        $f_info = static::get_field_info( $field );

		if ( ! empty( $f_info['taxonomy'] ) ) {
			$value = wp_get_object_terms( $this->get_id(), $field, array(
			    'fields' => 'ids'
            ) );
		} else {
			return parent::get_field_value( $field );
		}

		return apply_filters( "emu_{$entity}_get_field_value", $value, $field, $this );
	}

	/**
	 * Get entity author.
	 *
	 * @return false|WP_User
	 */
	public function get_author() {
		return get_user_by( 'ID', $this->get_wp_entity()->post_author );
	}

	/**
	 * @inheritdoc
	 */
	public function delete( $force = false ) {
		$entity = static::get_entity_name();
		do_action( "emu_{$entity}_before_delete", $this );
		wp_delete_post( $this->get_id(), $force );
		do_action( "emu_{$entity}_after_delete", $this );
	}

	/**
	 * @inheritdoc
	 */
	public function deactivate() {
		wp_update_post( array(
			'post_status' => 'draft',
			'ID' => $this->get_id(),
		) );
	}

	/**
	 * @return mixed
	 */
	public static function get_post_type_name() {
		return 'post';
	}

	/**
	 * Return entity type.
	 *
	 * @return string Return wp entity type like post or user.
	 */
	public static function get_entity_type() {
		return 'post';
	}
}
