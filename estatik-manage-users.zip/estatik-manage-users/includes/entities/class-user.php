<?php

/**
 * Class Emu_User
 *
 * @property $avatar_id
 */
class Emu_User extends Emu_Entity {

	/**
	 * User active status.
	 */
	const STATUS_ACTIVE = 1;
	const STATUS_DISABLED = 0;

    /**
     * @return array|mixed|void
     */
    public static function get_default_fields() {
        return apply_filters( 'emu_' . static::get_entity_name() . '_default_fields', array(
            'avatar_id' => array(
            	'is_single_meta' => true,
            ),
        ) );
    }

    /**
	 * @inheritdoc
	 */
	public function get_wp_entity() {
		if ( empty( $this->_wp_entity ) ) {
			$this->_wp_entity = new WP_User( $this->get_id() );
		}

		return $this->_wp_entity;
	}

    /**
     * Return user first name.
     *
     * @return string
     */
	public function get_full_name() {
	    $user = $this->get_wp_entity();
	    $name = array();

	    if ( ! empty( $user->first_name ) ) {
	        $name[] = $user->first_name;
        }

        if ( ! empty( $user->last_name ) ) {
            $name[] = $user->last_name;
        }

        $name = ! empty( $name ) ? implode( ' ', $name ) : null;

        return apply_filters( 'emu_user_get_full_name', $name, $this );
    }

	/**
	 * @return mixed|string
	 */
	public function get_email() {
		return $this->get_wp_entity()->user_email;
	}

	/**
	 * @inheritdoc
	 */
	public function delete( $force = false ) {
		wp_delete_user( $this->get_id() );
	}

	/**
	 * Change user status (active / disabled).
	 *
	 * @param $status
	 */
	public function change_status( $status ) {
		$old_status = $this->status;
		$this->save_field_value( 'status', $status );
		do_action( 'emu_' . static::get_entity_name() . '_after_change_status', $this, $status, $old_status );
	}

	/**
	 * Deactivate an agent
	 *
	 * @return void
	 */
	public function deactivate() {
		$this->change_status( self::STATUS_DISABLED );
	}

	/**
	 * Return entity type.
	 *
	 * @return string Return wp entity type like post or user.
	 */
	public static function get_entity_type() {
		return 'user';
	}

    /**
     * @return string
     */
    public function get_entity_prefix() {
        return 'emu_';
    }

    public static function get_entity_name() {
    	return 'user';
    }
}
