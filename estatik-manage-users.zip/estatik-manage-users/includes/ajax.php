<?php

/**
 * @param $message
 * @param $type
 *
 * @return array
 */
function emu_simple_ajax_response( $message, $type ) {
	return array(
		'status'  => $type,
		'message' => $message
	);
}

/**
 * @param $message
 *
 * @return array
 */
function emu_success_ajax_response( $message ) {
	return emu_simple_ajax_response( $message, 'success' );
}

/**
 * @param $message
 *
 * @return array
 */
function emu_error_ajax_response( $message ) {
	return emu_simple_ajax_response( $message, 'error' );
}

/**
 * Add / Delete item to / from wishlist via ajax.
 *
 * @return string
 */
function emu_ajax_wishlist_action() {
	$post_id = emu_clean( filter_input( INPUT_POST, 'post_id' ) );

	if ( $post_id ) {
		$wishlist = emu_get_wishlist_instance();

		if ( $wishlist->has( $post_id ) ) {
			$wishlist->remove( $post_id );
			wp_die( json_encode( emu_success_ajax_response( 'removed' ) ) );
		} else {
			$wishlist->add( $post_id );
			wp_die( json_encode( emu_success_ajax_response( 'added' ) ) );
		}
	} else {
		wp_die( json_encode( emu_error_ajax_response( __( 'Something wrong. Please contact the support.', 'es' ) ) ) );
	}
}
add_action( 'wp_ajax_emu_wishlist_action', 'emu_ajax_wishlist_action' );


/**
 * Save search actions.
 *
 * @return void
 */
function emu_ajax_save_search() {
	$response = array(
		'status' => 'error',
		'message' => __( 'Invalid security nonce. Please, reload the page and try again.', 'es' ),
	);

	if ( check_ajax_referer( 'emu_save_search', 'nonce' ) ) {
		$data = emu_array_filter_recursive( emu_clean( $_POST ), null, true );
		unset( $data['action'], $data['nonce'] );

		$data = apply_filters( 'emu_save_search_saving_fields', $data );

		if ( ! empty( $data ) && is_array( $data ) ) {
			$post_id = wp_insert_post( array(
				'post_type' => 'saved_search',
				'post_status' => 'private',
				'post_title' => '',
				'post_author' => get_current_user_id(),
			), true );

			if ( ! is_wp_error( $post_id ) ) {
				$saved_search = new Emu_Saved_Search( $post_id );
				$saved_search->save_fields( $data );

				$response = emu_simple_ajax_response( __( 'Search saved', 'es' ), 'success' );
			} else {
				$response = emu_simple_ajax_response( $post_id->get_error_message(), 'error' );
			}
		} else {
			$response = emu_simple_ajax_response( __( 'Search params are empty. Please fill search fields.', 'es' ), 'error' );
		}
	}

	wp_die( json_encode( $response ) );
}
add_action( 'wp_ajax_emu_save_search', 'emu_ajax_save_search' );

/**
 * Remove saved search via ajax.
 *
 * @return void
 */
function emu_ajax_remove_saved_search() {
	if ( wp_verify_nonce( emu_get_nonce( 'nonce' ), 'emu_remove_saved_search' ) ) {
		$post_id = emu_decode( emu_clean( filter_input(INPUT_POST, 'hash' ) ) );
		if ( is_array( $post_id ) && ! empty( $post_id[0] ) ) {
			$post_id = $post_id[0];
		}
		$saved_search = get_post( $post_id );
		if ( $post_id && $saved_search->post_author == get_current_user_id() ) {
			$saved_search = new Emu_Saved_Search( $post_id );
			$saved_search->delete( true );
			$response = emu_success_ajax_response( __( 'Successfully deleted.', 'es' ) );
		} else {
			$response = emu_error_ajax_response( __( 'Invalid saved search.', 'es' ) );
		}
	} else {
		$response = emu_error_ajax_response( __( 'Invalid security nonce. Please, reload the page and try again.', 'es' ) );
	}

	wp_die( json_encode( $response ) );
}
add_action( 'wp_ajax_emu_remove_saved_search', 'emu_ajax_remove_saved_search' );