<?php

/**
 * Class Emu_Auth.
 */
class Emu_Auth {

    /**
     * @return void
     */
    public static function init() {
        add_action( 'init', array( 'Emu_Auth', 'register' ) );
        add_action( 'init', array( 'Emu_Auth', 'login' ) );
        add_action( 'init', array( 'Emu_Auth', 'social_login' ) );
        add_action( 'init', array( 'Emu_Auth', 'retrieve_password' ) );
        add_action( 'init', array( 'Emu_Auth', 'reset_password' ) );
    }

	/**
	 * @param $data
	 *
	 * @return mixed
	 */
    public static function wrap_email( $data ) {
	    ob_start();
	    $data['message'] = wpautop( $data['message'] );
	    emu_load_template( 'common/emails/template.php', array( 'content' => $data['message'] ) );
	    $data['message'] = ob_get_clean();

	    if ( empty( $data['headers'] ) && is_string( $data['headers'] ) ) {
		    $data['headers'] = array();
	    }
	    $data['headers']['content-type'] = 'text/html';

	    return $data;
    }

	/**
	 * @param $wp_new_user_notification_email array
	 * @param $user WP_User
	 *
	 * @return array|void
	 */
    public static function user_notification_email( $wp_new_user_notification_email, $user ) {
	    $key = get_password_reset_key( $user );
	    if ( is_wp_error( $key ) ) {
		    return;
	    }

	    $user_login = $user->user_login;

	    switch_to_locale( get_user_locale( $user ) );

	    $query_args = array(
		    'auth_item' => 'reset-form',
		    'key' => $key,
		    'login' => rawurlencode( $user_login ),
	    );

	    $login_page_id = ests( 'login_page_id' );

	    if ( $login_page_id && get_post_status( $login_page_id ) == 'publish' ) {
		    $link = add_query_arg( $query_args, get_permalink( $login_page_id ) );
	    } else {
		    $link = network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user_login ), 'login' );
	    }

	    /* translators: %s: User login. */
// 	    $message  = sprintf( __( 'Username: %s' ), $user->user_login ) . "\r\n\r\n";
	    $message = "Thank you for setting up your profile with Holiday Homes Spain.";
	    $message .= sprintf( __( 'To set your password, visit the following <a href="%s">link</a>.', 'es' ), $link ) . "\r\n\r\n";
		
		$message .= "You can now save searches, save individual properties and share these with friends and family.\r\n\r\nWe look forward to helping you find your home in the sun.\r\n\r\n";

	    $wp_new_user_notification_email['message'] = $message;

	    return $wp_new_user_notification_email;
    }

    /**
     * Register new user using register form.
     *
     * @return void
     */
    public static function register() {
        if ( wp_verify_nonce( emu_get_nonce( 'emu_register_nonce' ), 'emu_register' ) ) {
            $email = emu_clean( filter_input( INPUT_POST, 'emu_user_email' ) );
            $password = filter_input( INPUT_POST, 'emu_user_password' );
            $is_popup = emu_clean( filter_input( INPUT_POST, 'is_popup' ) );

            if ( $user_id = email_exists( $email ) ) {
                $auth_list = emu_get_auth_networks_list();
                $social_network_exists = false;

                $user = wp_signon( array(
                    'user_login' => emu_clean( filter_input( INPUT_POST, 'emu_user_login' ) ),
                    'user_password' => filter_input( INPUT_POST, 'emu_user_password' ),
                    'remember' => true,
                ), is_ssl() );

                if ( $user instanceof WP_User ) {
                    wp_safe_redirect( emu_get_success_auth_redirect_url() );
                    die;
                } else {
                    foreach ( $auth_list as $auth_item ) {
                        if ( get_user_meta( $user_id, 'auth_' . $auth_item, true ) ) {
                            $social_network_exists = true;
                            emu_set_flash( 'authenticate', sprintf( __( 'You already created an account using %s. Please log in instead.', 'es' ), ucfirst( $auth_item ) ), 'error' );
                            break;
                        }
                    }

                    if ( ! $social_network_exists ) {
                        emu_set_flash( 'authenticate', __( 'The email address you use has already been registered. Please log in.', 'es' ), 'error' );
                    }

                    wp_safe_redirect( emu_get_auth_page_uri( 'buyer-register-form', $_SERVER['HTTP_REFERER'], $is_popup ) );
                    die;
                }
            } else {
                $user_data = array(
                    'user_login' => $email,
                    'user_pass'  => $password,
                    'user_email' => $email,
                );

                $user_id = wp_insert_user( $user_data );

                if ( is_wp_error( $user_id ) ) {
                    emu_set_wp_error_flash( 'authenticate', $user_id );

                    wp_safe_redirect( emu_get_auth_page_uri( 'buyer-register-form', $_SERVER['HTTP_REFERER'], $is_popup ) );
                    die;
                } else {
	                add_filter( 'wp_new_user_notification_email_admin', array( 'Emu_Auth', 'wrap_email' ) );
	                add_filter( 'wp_new_user_notification_email', array( 'Emu_Auth', 'user_notification_email' ), 10, 2 );
	                add_filter( 'wp_new_user_notification_email', array( 'Emu_Auth', 'wrap_email' ) );

                	do_action( 'register_new_user', $user_id );

	                emu_set_flash( 'authenticate', __( 'You have successfully registered. Please log in.', 'es' ), 'success' );

	                wp_safe_redirect( emu_get_auth_page_uri( 'login-form', $_SERVER['HTTP_REFERER'], $is_popup ) );
                    die;
                }
            }

        }
    }

    /**
     * Login user using authenticate form.
     *
     * @return void
     */
    public static function login() {
        if ( wp_verify_nonce( emu_get_nonce( 'emu_auth_nonce' ), 'emu_authenticate' ) ) {
            $credentials = array(
                'user_login' => emu_clean( filter_input( INPUT_POST, 'emu_user_login' ) ),
                'user_password' => filter_input( INPUT_POST, 'emu_user_password' ),
                'remember' => true,
            );

	        $is_popup = emu_clean( filter_input( INPUT_POST, 'is_popup' ) );
            $user = wp_signon( $credentials, is_ssl() );

            if ( is_wp_error( $user ) ) {
                emu_set_wp_error_flash( 'authenticate', $user );
                wp_safe_redirect( emu_get_auth_page_uri( 'login-form', $_SERVER['HTTP_REFERER'], $is_popup ) );
                die;
            } else {
                wp_safe_redirect( emu_get_success_auth_redirect_url() );
                die;
            }

        }
    }

    /**
     * Login user via social networks.
     *
     * @return void
     */
    public static function social_login() {
        $auth_network = emu_clean( filter_input( INPUT_GET, 'auth_network' ) );
        $networks = emu_get_auth_networks_list();

        if ( ! empty( $auth_network ) && in_array( $auth_network, $networks ) ) {
            $network = emu_get_auth_instance( $auth_network, emu_clean( $_GET ) );
            $config = $network->get_config();

            try {
                $network->auth();
                wp_safe_redirect( emu_get_success_auth_redirect_url() );
                die;
            } catch ( Exception $e ) {
                emu_set_flash( 'authenticate', $e->getMessage(), 'error' );
                wp_safe_redirect( emu_get_auth_page_uri( $config['context'], site_url() ) );
                die;
            }
        }
    }

    /**
     * Retrieve reset password link.
     *
     * @return void
     */
    public static function retrieve_password() {
        if ( wp_verify_nonce( emu_get_nonce( 'emu_retrieve_pwd_nonce' ), 'emu_retrieve_pwd' ) ) {
            $email = emu_clean( filter_input( INPUT_POST, 'emu_user_email' ) );
	        $is_popup = emu_clean( filter_input( INPUT_POST, 'is_popup' ) );

            if ( $user_id = email_exists( $email ) ) {
                $user = get_user_by( 'id', $user_id );
                $_POST['user_login'] = $user->user_login;

	            $result = static::retrieve_password_send();

                if ( is_wp_error( $result ) ) {
                    emu_set_wp_error_flash( 'authenticate', $result );
                } else {
                    emu_set_flash( 'authenticate', sprintf( __( 'A reset link is on its way. Please check your email inbox for %s and click the link to reset your password.', 'es' ), $user->user_email ) );
                }
            } else {
                emu_set_flash( 'authenticate', __( 'User doesn\'t exist', 'es' ), 'error' );
            }

            $prev_url = esc_url( filter_input( INPUT_POST, '_wp_http_referer' ) );
            wp_safe_redirect( emu_get_auth_page_uri( 'reset-form', $prev_url, $is_popup ) );
            die;
        }
    }

    /**
     * Set new user password action.
     *
     * @return void
     */
    public static function reset_password() {
        if ( wp_verify_nonce( emu_get_nonce( 'emu_reset_pwd_nonce' ), 'emu_reset_pwd' ) ) {
            $key = sanitize_text_field( filter_input( INPUT_POST, 'key' ) );
            $login = sanitize_text_field( filter_input( INPUT_POST, 'login' ) );
	        $is_popup = emu_clean( filter_input( INPUT_POST, 'is_popup' ) );

            if ( $key && $login ) {
                $user = check_password_reset_key( $key, $login );
                if ( is_wp_error( $user ) ) {
                    emu_set_wp_error_flash( 'authenticate', $user );
                } else {
	                add_filter( 'wp_password_change_notification_email', array( 'Emu_Auth', 'wrap_email' ) );
                    reset_password( $user, sanitize_text_field( $_POST['pwd'] ) );
                    emu_set_flash( 'authenticate', __( 'Password successfully changed.', 'es' ), 'success' );
                }
            }

            $prev_url = esc_url( filter_input( INPUT_POST, '_wp_http_referer' ) );
            wp_safe_redirect( emu_get_auth_page_uri( 'login-form', $prev_url, $is_popup ) );
            die;
        }
    }

	/**
	 * Handles sending password retrieval email to user.
	 *
	 * @since 2.5.0
	 *
	 * @return bool|WP_Error True: when finish. WP_Error on error
	 */
	public static function retrieve_password_send() {
		$errors = new WP_Error();

		if ( empty( $_POST['user_login'] ) || ! is_string( $_POST['user_login'] ) ) {
			$errors->add( 'empty_username', __( '<strong>ERROR</strong>: Enter a username or email address.' ) );
		} elseif ( strpos( $_POST['user_login'], '@' ) ) {
			$user_data = get_user_by( 'email', trim( wp_unslash( $_POST['user_login'] ) ) );
			if ( empty( $user_data ) ) {
				$errors->add( 'invalid_email', __( '<strong>ERROR</strong>: There is no account with that username or email address.' ) );
			}
		} else {
			$login     = trim( $_POST['user_login'] );
			$user_data = get_user_by( 'login', $login );
		}

		/**
		 * Fires before errors are returned from a password reset request.
		 *
		 * @since 2.1.0
		 * @since 4.4.0 Added the `$errors` parameter.
		 *
		 * @param WP_Error $errors A WP_Error object containing any errors generated
		 *                         by using invalid credentials.
		 */
		do_action( 'lostpassword_post', $errors );

		if ( $errors->has_errors() ) {
			return $errors;
		}

		if ( ! $user_data ) {
			$errors->add( 'invalidcombo', __( '<strong>ERROR</strong>: There is no account with that username or email address.' ) );
			return $errors;
		}

		// Redefining user_login ensures we return the right case in the email.
		$user_login = $user_data->user_login;
		$user_email = $user_data->user_email;
		$key        = get_password_reset_key( $user_data );

		if ( is_wp_error( $key ) ) {
			return $key;
		}

		if ( is_multisite() ) {
			$site_name = get_network()->site_name;
		} else {
			/*
			 * The blogname option is escaped with esc_html on the way into the database
			 * in sanitize_option we want to reverse this for the plain text arena of emails.
			 */
			$site_name = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
		}

		$query_args = array(
			'auth_item' => 'reset-form',
			'key' => $key,
			'login' => rawurlencode( $user_login ),
		);

		$login_page_id = ests( 'login_page_id' );

		if ( $login_page_id && get_post_status( $login_page_id ) == 'publish' ) {
			$link = add_query_arg( $query_args, get_permalink( $login_page_id ) );
		} else {
			$link = network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user_login ), 'login' );
		}

		$message = __( 'Someone has requested a password reset for the following account:' ) . "<br><br>";
		/* translators: %s: Site name. */
		$message .= sprintf( __( 'Site Name: %s' ), $site_name ) . "<br>";
		/* translators: %s: User login. */
		$message .= sprintf( __( 'Username: %s' ), $user_login ) . "<br><br>";
		$message .= __( 'If this was a mistake, just ignore this email and nothing will happen.' ) . "<br><br>";
		$message .= sprintf( __( 'To reset your password, visit the following <a href="%s">link</a>.', 'es' ), $link ) . "<br>";

		ob_start();
		emu_load_template( 'common/emails/template.php', array( 'content' => $message ) );
		$message = ob_get_clean();

		/* translators: Password reset notification email subject. %s: Site title. */
		$title = sprintf( __( '[%s] Password Reset' ), $site_name );

		/**
		 * Filters the subject of the password reset email.
		 *
		 * @since 2.8.0
		 * @since 4.4.0 Added the `$user_login` and `$user_data` parameters.
		 *
		 * @param string  $title      Default email title.
		 * @param string  $user_login The username for the user.
		 * @param WP_User $user_data  WP_User object.
		 */
		$title = apply_filters( 'retrieve_password_title', $title, $user_login, $user_data );

		/**
		 * Filters the message body of the password reset mail.
		 *
		 * If the filtered message is empty, the password reset email will not be sent.
		 *
		 * @since 2.8.0
		 * @since 4.1.0 Added `$user_login` and `$user_data` parameters.
		 *
		 * @param string  $message    Default mail message.
		 * @param string  $key        The activation key.
		 * @param string  $user_login The username for the user.
		 * @param WP_User $user_data  WP_User object.
		 */
		$message = apply_filters( 'retrieve_password_message', $message, $key, $user_login, $user_data );

		if ( $message && ! wp_mail( $user_email, wp_specialchars_decode( $title ), $message ) ) {
			$errors->add(
				'retrieve_password_email_failure',
				sprintf(
				/* translators: %s: Documentation URL. */
					__( '<strong>ERROR</strong>: The email could not be sent. Your site may not be correctly configured to send emails. <a href="%s">Get support for resetting your password</a>.' ),
					esc_url( __( 'https://wordpress.org/support/article/resetting-your-password/' ) )
				)
			);
			return $errors;
		}

		return true;
	}
}

Emu_Auth::init();
