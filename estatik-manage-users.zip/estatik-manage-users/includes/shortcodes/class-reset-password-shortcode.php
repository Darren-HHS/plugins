<?php

class Emu_Restore_Password_Shortcode extends Emu_Shortcode {

    /**
     * Return shortcode content.
     *
     * @return string
     */
    public function get_content() {
        $shortcode = emu_get_shortcode_instance( 'emu_authentication', array(
            'auth_item' => 'reset-form',
        ) );

        return $shortcode->get_content();
    }

    /**
     * Return shortcode name.
     *
     * @return string
     */
    public static function get_shortcode_name() {
        return 'emu_reset_pwd';
    }
}