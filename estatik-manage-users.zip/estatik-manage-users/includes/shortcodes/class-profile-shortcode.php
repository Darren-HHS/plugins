<?php

/**
 * Class Emu_Profile_Shortcode.
 */
class Emu_Profile_Shortcode extends Emu_Shortcode {

    /**
     * Return shortcode name.
     *
     * @return string
     */
    public static function get_shortcode_name() {
        return 'emu_profile';
    }

    /**
     * @return false|string
     */
    public function get_content() {
        ob_start();

        if ( get_current_user_id() ) {
            emu_load_template( 'front/shortcodes/profile/profile.php', array(
                'user_entity' => new Emu_User( get_current_user_id() ),
                'tabs' => array(
                    'saved-homes' => array(
                        'template' => emu_locate_template( 'front/shortcodes/profile/tabs/saved-homes.php' ),
                        'label' => __( 'Saved homes', 'es' ),
                        'icon' => "<span class='es-icon es-icon_heart'></span>",
                        'id' => 'saved-homes',
                    ),
                    'saved-searches' => array(
                        'template' => emu_locate_template( 'front/shortcodes/profile/tabs/saved-searches.php' ),
                        'label' => __( 'Saved searches', 'es' ),
                        'icon' => "<span class='es-icon es-icon_search'></span>",
                        'id' => 'saved-searches',
                    ),
                ),
            ) );
        } else {
            $shortcode = emu_get_shortcode_instance( 'emu_authentication' );
            echo $shortcode->get_content();
        }
        return ob_get_clean();
    }
}
