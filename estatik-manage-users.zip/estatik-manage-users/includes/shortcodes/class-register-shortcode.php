<?php

/**
 * Class Emu_Register_Shortcode.
 */
class Emu_Register_Shortcode extends Emu_Shortcode {

    /**
     * Return shortcode content.
     *
     * @return string
     */
    public function get_content() {
        $shortcode = emu_get_shortcode_instance( 'emu_authentication', array(
            'auth_item' => 'buyer-register-form',
        ) );

        return $shortcode->get_content();
    }

    /**
     * Return shortcode name.
     *
     * @return string
     */
    public static function get_shortcode_name() {
        return 'emu_register';
    }
}
