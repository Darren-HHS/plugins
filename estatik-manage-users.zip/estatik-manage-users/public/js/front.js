( function( $ ) {
    'use strict';

    $( function() {
        $( document ).on( 'click', '.js-emu-remove-saved-search', function() {
            var $btn = $( this );
            var $wrapper = $btn.closest( '#saved-searches' );
            var $items_wrapper = $btn.closest( '.es-saved-searches' );
            var $item_wrapper = $btn.closest( '.js-es-saved-search' );

            $( this ).addClass( 'es-loading' );

            $.post( EMU.settings.ajaxurl, {
                action: 'emu_remove_saved_search',
                hash: $( this ).data('hash'),
                nonce: EMU.nonce.saved_search
            }, function( response ) {
                response = response || {};

                if ( response.status === 'success' ) {
                    if ( $item_wrapper.length ) {
                        $item_wrapper.fadeOut( 400, function() {
                            $item_wrapper.remove();

                            if ( ! $items_wrapper.find( '.js-es-saved-search' ).length ) {
                                $wrapper.find( '.js-es-no-posts' ).removeClass( 'es-hidden' );
                                $items_wrapper.remove();
                            }
                        } );
                    }
                } else {
                    alert( response.message );
                }
            }, 'json' ).fail( function() {
                alert( EMU.tr.unknown_error );
            } ).always( function() {
                $btn.removeClass( 'es-loading' );
            } );
            return false;
        } );

        $( document ).on( 'click', '.js-emu-save-search:not(.es-loading)', function() {
            var $btn = $( this );
            $btn.addClass( 'es-loading' );
            var data = $btn.closest( '#wiidoo_searcher' ).find('select, textarea, input').serialize();
            data += '&action=emu_save_search&nonce=' + $btn.data( 'nonce' );

            $btn.prop( 'disabled', 'disabled' );

            $.post( EMU.settings.ajaxurl, data, function( response ) {
                response = response || {};

                if ( response.status === 'success' ) {
                    $btn.html( response.message );
                }
            }, 'json' ).always( function() {
                $btn.addClass( 'es-loading' ).removeProp( 'disabled' );
            } );

            return false;
        } );

        $( document ).on( 'click', '.js-es-wishlist:not(.es-loading)', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $el = $( this );
            $el.addClass( 'es-loading' );

            var data = {
                post_id: $el.data( 'id' ),
                action: 'emu_wishlist_action'
            };

            $.post( EMU.settings.ajaxurl, data, function( response ) {
                response = response || {};

                if ( response.status === 'success' ) {
                    if ( response.message === 'added' ) {
                        $el.addClass( 'es-wishlist-btn--active' );
                    } else {

                        if ( $el.closest( '#saved-homes' ).length ) {
                            $el.closest( '.es-resales-item' ).remove();
                        }
                        $el.removeClass( 'es-wishlist-btn--active' );
                    }
                } else {
                    if ( response.message ) {
                        alert( response.message );
                    }
                }
            }, 'json' ).always( function() {
                $el.removeClass( 'es-loading' );
            } );

            return false;
        } );

        $( document ).on( 'click', '.js-es-auth-item__switcher', function() {
            var $wrapper = $( this ).closest( '.js-es-auth' );
            var auth_item = $( this ).data( 'auth-item' );
            $wrapper.find( '.es-auth__item' ).addClass( 'es-auth__item--hidden' );
            $wrapper.find( '.es-auth__' + auth_item ).removeClass( 'es-auth__item--hidden' );
            return false;
        } );

        $( document ).on( 'click', '.js-es-toggle-pwd', function() {
            var $field = $( this ).closest( '.es-field' ).find( 'input' );
            $( this ).toggleClass( 'es-secondary-color' );
            if ( $field.attr( 'type' ) === 'text' ) {
                $field.prop( 'type', 'password' );
            } else {
                $field.prop( 'type', 'text' );
            }

            return false;
        } );

        $( document ).on( 'change', '.js-es-submit-on-change', function() {
            $( this ).closest( 'form' ).submit();
        } );

        if ( typeof ClipboardJS !== 'undefined' ) {

            new ClipboardJS( '.js-es-property-copy', {
                container: $( '#es-share-popup' )[0]
            } );

            $( document ).on( 'click', '.js-es-copy', function() {
                var $link = $( this );

                if ( ! $link.hasClass( 'es-copy--active' ) ) {
                    var copied_label = $link.data( 'copied' ) || 'Copied';
                    var temp_label = $link.html();
                    $link.addClass( 'es-copy--active' );

                    if ( copied_label ) {
                        $link.html( copied_label );
                        setTimeout( function() {
                            $link.html( temp_label );
                            $link.removeClass( 'es-copy--active' );
                        } , 4000 );
                    }
                }

                return false;
            } );
        }
    } );
} )( jQuery );
