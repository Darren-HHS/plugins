<?php

/**
 * @var $user_entity Emu_User
 * @var $tabs array
 */

$flashes = emu_get_flash_instance( 'profile' );
$current_tab = filter_input( INPUT_GET, 'tab' );
$current_tab = $current_tab ? $current_tab : 'saved-homes'; ?>
<div class="es-profile js-es-profile">
    <div class="es-profile__flashes"><?php $flashes->render_messages(); ?></div>
    <div class="es-profile__nav-bar">
        <div class="es-profile__nav-bar__user">
            <div class="es-profile__image">
                <a href="<?php echo add_query_arg( array( 'tab' => 'user' ) ); ?>">
                    <?php echo get_avatar( $user_entity->get_id() ); ?>
                </a>
            </div>
            <b class="es-user__name">
                <a href="<?php echo add_query_arg( array( 'tab' => 'user' ) ); ?>">
                    <?php echo $user_entity->get_full_name() ?
                        $user_entity->get_full_name() : $user_entity->get_email(); ?>
                </a>
            </b>
        </div>

        <form action="" method="get">
            <div class="es-field es-field__tab es-field--select ">
                <label for="es-field-tab">
                    <select id="es-field-tab" name="tab" class="js-es-submit-on-change es-field__input"><option value=""></option><option value="saved-homes">Saved homes</option><option value="saved-searches">Saved searches</option></select>
                </label>
            </div>
        </form>
    </div>
    <div class="es-profile__sidebar">
        <a href="<?php echo add_query_arg( array( 'tab' => 'user' ) ); ?>">
            <div class="es-profile__sidebar__user">
                <div class="es-profile__image">
                    <?php echo get_avatar( $user_entity->get_id() ); ?>
                </div>
                <b class="es-user__name">
                    <?php echo $user_entity->get_full_name() ?
                        $user_entity->get_full_name() : $user_entity->get_email(); ?>
                </b>
            </div>
        </a>
        <ul class="es-profile__menu">
            <?php foreach ( $tabs as $id => $tab_config ) : ?>
                <li class="<?php emu_active_class( $id, $current_tab, 'active' ); ?>">
                    <a href="<?php echo add_query_arg( array( 'tab' => $id ) ); ?>"><?php echo $tab_config['icon'] . $tab_config['label']; ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="es-profile__main">
        <?php if ( ! empty( $tabs[ $current_tab ]['template'] ) ) : ?>
            <?php include( $tabs[ $current_tab ]['template'] ); ?>
        <?php else: ?>
            <?php emu_load_template( 'front/shortcodes/profile/tabs/profile-form.php', array(
                'user_entity' => $user_entity,
            ) ); ?>
        <?php endif; ?>
    </div>
</div>
<?php do_action( 'emu_after_profile' ); ?>