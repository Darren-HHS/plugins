<div id="<?php echo $current_tab; ?>">
    <?php if ( ! empty( $tabs[ $current_tab ]['label'] ) ) : ?>
        <h2 class="heading-font"><?php echo $tabs[ $current_tab ]['label']; ?></h2>
    <?php endif;

    $wishlist = emu_get_wishlist_instance(); ?>

    <?php if ( $items = $wishlist->get_items_ids() ) :
	    $roh_api_key = esc_attr( get_option( 'roh-api-key' ) );
	    $roh_client_id = esc_attr( get_option( 'roh-client-id' ) );
	    $cnt = 0; ?>

        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); grid-gap: 20px;">

        <?php foreach ( $items as $P_RefId ) :
	        $data = array(
		        "p1" => $roh_client_id,
		        "p2" => $roh_api_key,
		        "P_ApiId" => esc_attr( get_option( 'roh-filter-id-1' ) ),
		        "P_RefId" => $P_RefId,
	        );
	        $url = "https://webapi.resales-online.com/V6/PropertyDetails";
	        $query_url = sprintf( "%s?%s", $url, http_build_query( $data ) );
	        $api = file_get_contents( $query_url );
	        $api_resp = json_decode( $api );

	        if ( ! empty( $api_resp->Property ) ) :
                $property = $api_resp->Property;
	            $Reference = $property->Reference;
                $SearchType = $api_resp->QueryInfo->SearchType;
                $P_QueryId  = $api_resp->QueryInfo->QueryId;
                $MainImage = $property->Pictures->Picture[0]->PictureURL;
                $Price = $property->Price;
                $Bedrooms  = $property->Bedrooms;
                $Built       = $property->Built;
                $Terrace     = $property->Terrace;
                $GardenPlot  = $property->GardenPlot;
                $Description = $property->Description;
                $Location  = $property->Location;
                $tot_plot    = $Built + $Terrace + $GardenPlot;
                $Type      = $property->PropertyType->NameType;
                $Bathrooms = $property->Bathrooms;
                $Price = number_format( $Price );
                $Price = '&euro;' . $Price; ?>

                <div class="es-resales-item">
                <form id="prop_viewor_<?php echo $cnt++; ?>" action="/property-details/" method="get">
                    <div class="w3-col" style="position: relative; cursor:pointer; display:block;">
                    <?php if ( get_current_user_id() ) : $wishlist = emu_get_wishlist_instance(); ?>
                        <button type="button" class="es-wishlist-btn <?php echo $wishlist->has( $Reference ) ? 'es-wishlist-btn--active' : ''; ?> js-es-wishlist" data-id="<?php echo $Reference; ?>"></button>
                    <?php else : ?>
                        <a href="<?php echo emu_get_auth_page_uri( 'login-form' ); ?>" class="es-wishlist-btn"></a>
                    <?php endif; ?>
                    <div class="w3-display-container" onclick="prop_view('<?php echo $cnt; ?>')">
                        <div style="background-image:url(../wp-content/plugins/resales-marbella-wp-master/images/loading4.gif);background-position:center center;background-repeat:no-repeat">
                            <div style="background-image:url(<?php echo $MainImage; ?>);background-size:cover;background-position:center center;height: 300px"></div>
                         </div>
                    <div class="w3-display-topleft w3-text-white"><p style="padding-left:13px;text-shadow: 1px 1px 1px #000;"><b><?php echo $Reference; ?></b></p></div>
                    <div class="w3-display-topright w3-card-4 w3-opacity-min" style="margin-top:13px;padding:8px;text-align:center;background-color:#ebebeb">
                    <?php if ( $SearchType != 'Short Term Rental' ) {
                        if ( $SearchType != 'Long Term Rental' ) {
                            //for sale
                            echo '<h5 style="margin:0px;color:black;text-transform:uppercase;"><b>For Sale<br>' . $Price . '</b></h5>';
                        } else {
                            //Long Term Rental
                            echo '<h5 style="margin:0px;color:black;text-transform:uppercase;"><b>Long Term Rentals<br>' . $Price . '</b></h5>';
                        }
                    } else {
                        //Short Term Rental
                        echo '<h5 style="margin:0px;color:black;text-transform:uppercase;"><b>Holiday Rentals<br>' . $Price . '</b></h5>';
                    }

                    echo ' </div>
            
                  <div class="w3-display-bottommiddle w3-black w3-opacity-min" style="width:100%;padding:5px;font-size:17px;font-weight:300;">
                    <div class="w3-row">
                        <div class="w3-col l6 m6 s6">
                        <i class="fas fa-expand"></i> ' . $tot_plot . ' <span style="font-size:75%">m2</span>
                        </div>
                        <div class="w3-col l6 m6 s6">
                        <i class="fas fa-home"></i> ' . $Built . ' <span style="font-size:75%">m2</span>
                        </div>
                        <div class="w3-col l6 m6 s6">
                        <i class="fa fa-bed"></i> ' . $Bedrooms . '
                        </div>
                        <div class="w3-col l6 m6 s6">
                        <img class="w3-image" src="' . $bath_img . '" style="max-height:17px;margin-top:3px"> ' . $Bathrooms . '
                        </div>
                    </div>
                  </div>  
                 <input type="hidden" id="P_RefId" name="P_RefId" value="' . $Reference . '">
                 <input type="hidden" id="P_ApiId" name="P_ApiId" value="' . $P_ApiId . '">
        
                </div>
             <div class="" style="background-color:#ebebeb;height:89px">      
                   <h4 style="text-transform:uppercase;margin-top:0px;font-weight:bold;padding:13px;line-height:99%">' . $Type . ' in ' . $Location . '</h4>
             </div>  
              </div>
            </form>
            </div>';

            endif; ?>

        <?php endforeach; ?>
        </div>

    <?php endif; ?>

    <div class="js-es-no-posts <?php echo ! empty( $items ) ? 'es-hidden' : ''; ?>  ">
        <p class="es-subtitle"><?php _e( 'You haven’t saved any homes yet.', 'es' ); ?></p>
        <p><?php _e( 'Start searching for properties to add now.', 'es' ); ?></p>
		<?php if ( $url = emu_get_search_page_url() ) : ?>
            <a href="<?php echo $url; ?>" class="emu-btn emu-btn--secondary">
                <span class="es-icon es-icon_search"></span><?php _e( 'Go to search', 'es' ); ?>
            </a>
		<?php endif; ?>
    </div>
</div>
