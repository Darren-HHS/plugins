<?php

/**
 * @var $args array
 */

$flashes = emu_get_flash_instance( 'authenticate' ); ?>
<div class="es-auth js-es-auth content-font">
    <?php $flashes->render_messages(); ?>
    <?php emu_load_template( 'front/shortcodes/authentication/login-buttons.php', $args ); ?>
    <?php emu_load_template( 'front/shortcodes/authentication/login-form.php', $args ); ?>
    <?php emu_load_template( 'front/shortcodes/authentication/reset-form.php', $args ); ?>
    <?php emu_load_template( 'front/shortcodes/authentication/buyer-register-buttons.php', $args ); ?>
    <?php emu_load_template( 'front/shortcodes/authentication/buyer-register-form.php', $args ); ?>

    <?php do_action( 'emu_after_authentication' ); ?>
</div>
