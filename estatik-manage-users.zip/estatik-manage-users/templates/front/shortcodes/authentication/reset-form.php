<?php /** @var $args array */ ?>
<div class="es-auth__item es-auth__reset-form <?php echo $args['auth_item'] != 'reset-form' ? 'es-auth__item--hidden' : ''; ?>">
    <h3 class="heading-font"><?php _e( 'Reset password' ); ?></h3>
    <p><?php _e( 'Enter your email address and we will send you a link to change your password.', 'es' ); ?></p>

    <form action="" method="POST">
	    <?php if ( ! empty( $args['is_popup'] ) ) : ?>
            <input type="hidden" name="is_popup" value="1">
	    <?php endif; ?>
        <?php if ( ! empty( $_GET['key'] ) && ! empty( $_GET['login'] ) ) :
            $key = sanitize_text_field( filter_input( INPUT_GET, 'key' ) );
            $login = sanitize_text_field( filter_input( INPUT_GET, 'login' ) );
            $user = get_user_by( 'login', $login ); ?>
            <input type="hidden" name="login" value="<?php echo esc_attr( $login ); ?>"/>
            <input type="hidden" name="key" value="<?php echo esc_attr( $key ); ?>"/>

            <div class="es-field es-field__es_new_password es-field--password ">
                <label for="es-field-es_new_password"><div class="es-field__label">New password</div><div class="es-input__wrap"><input id="es-field-es_new_password" name="es_new_password" class="js-es-password-field es-field__input" required="required" type="password" value=""><a href="#" class="es-toggle-pwd js-es-toggle-pwd"><span class="es-icon es-icon_eye"></span></a></div><p class="es-field__description"></p><ul class="es-field__validate-list">
                        <li class="es-validate-item es-validate-item__contain">Can't contain the name or email address</li>
                        <li class="es-validate-item es-validate-item__length">At least 8 characters</li>
                        <li class="es-validate-item es-validate-item__char">Contains a number or symbol</li>
                    </ul><p></p></label>
            </div>

            <?php wp_nonce_field( 'emu_reset_pwd', 'emu_reset_pwd_nonce' ); ?>
            <button type="submit" class="emu-btn emu-btn--primary emu-btn--reset"><?php _e( 'Save new password', 'es' ); ?></button>
        <?php else : ?>
            <div class="es-field es-field__es_user_email es-field--email ">
                <label for="es-field-es_user_email">
                    <div class="es-field__label">Email</div>
                    <input id="es-field-es_user_email" name="emu_user_email" class="es-field__input" required="required" type="email" value="">
                </label>
            </div>
            <?php wp_nonce_field( 'emu_retrieve_pwd', 'emu_retrieve_pwd_nonce' ); ?>
            <button type="submit" class="emu-btn emu-btn--primary emu-btn--reset"><?php _e( 'Send reset link', 'es' ); ?></button>
        <?php endif; ?>

        <div><a href="#" data-auth-item="login-buttons" class="js-es-auth-item__switcher login-back"><span class="es-icon es-icon_chevron-left"></span><?php _e( 'Back to login', 'es' ); ?></a></div>
    </form>
</div>
