<?php /** @var $args array */ ?>
<div class="es-auth__item js-es-auth__login-form es-auth__login-form <?php echo $args['auth_item'] != 'login-form' ? 'es-auth__item--hidden' : ''; ?>">
    <?php if ( ! empty( $args['login_title'] ) ) : ?>
        <h3 class="heading-font"><?php echo $args['login_title']; ?></h3>
    <?php endif; ?>

    <?php if ( ! empty( $args['login_subtitle'] ) ) : ?>
        <p><?php echo $args['login_subtitle']; ?></p>
    <?php endif; ?>

    <div class="all-login-back">
        <a href="#" data-auth-item="login-buttons" class="js-es-auth-item__switcher">
            <span class="es-icon es-icon_chevron-left"></span><?php _e( 'All log in options', 'es' ); ?>
        </a>
    </div>

    <form action="" method="POST">
        <div class="es-field es-field__es_user_login es-field--text ">
            <label for="es-field-es_user_login">
                <div class="es-field__label">Email</div>
                <input id="es-field-es_user_login" name="emu_user_login" class="es-field__input" required="required" type="text" value="">
            </label>
        </div>
        <div class="es-field es-field__es_user_password es-field--password ">
            <label for="es-field-es_user_password">
                <div class="es-field__label">Password</div>
                <div class="es-input__wrap">
                    <input id="es-field-es_user_password" name="emu_user_password" class="es-field__input" required="required" type="password" value="">
                    <a href="#" class="es-toggle-pwd js-es-toggle-pwd"><span class="es-icon es-icon_eye"></span></a>
                </div>
            </label>
        </div>
        <div class="forgot-pwd">
            <a href="#" data-auth-item="reset-form" class="js-es-auth-item__switcher"><?php _e( 'Forgot password?', 'es' ); ?></a>
        </div>

	    <?php if ( ! empty( $args['is_popup'] ) ) : ?>
            <input type="hidden" name="is_popup" value="1">
	    <?php endif; ?>
        <?php wp_nonce_field( 'emu_authenticate', 'emu_auth_nonce' ); ?>
        <button type="submit" class="emu-btn emu-btn--primary js-emu-btn--login emu-btn--login"><?php _e( 'Log in', 'es' ); ?></button>
    </form>

    <?php if ( ! empty( $args['enable_buyers_register'] ) ) : ?>
        <p class="sign-in-text"><?php _e( 'Don\'t have an account? <a href="#" class="js-es-auth-item__switcher" data-auth-item="buyer-register-buttons">Sign up</a>', 'es' ); ?></p>
    <?php endif; ?>
</div>
