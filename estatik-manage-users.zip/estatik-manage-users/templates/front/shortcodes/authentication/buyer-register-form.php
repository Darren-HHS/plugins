<?php /** @var $args array */ ?>
<div class="es-auth__item es-auth__buyer-register-form <?php echo $args['auth_item'] != 'buyer-register-form' ? 'es-auth__item--hidden' : ''; ?>">
    <?php if ( ! empty( $args['buyer_register_title'] ) ) : ?>
        <h3 class="heading-font"><?php echo $args['buyer_register_title']; ?></h3>
    <?php endif; ?>

    <?php if ( ! empty( $args['buyer_register_subtitle'] ) ) : ?>
        <p><?php echo $args['buyer_register_subtitle']; ?></p>
    <?php endif; ?>

    <div class="all-login-back">
        <a href="#" class="js-es-auth-item__switcher" data-auth-item="buyer-register-buttons">
            <span class="es-icon es-icon_chevron-left"></span><?php _e( 'All sign up options', 'es' ); ?>
        </a>
    </div>

    <form action="" method="POST">
        <?php wp_nonce_field( 'emu_register', 'emu_register_nonce' ); ?>
        <?php if ( ! empty( $args['is_popup'] ) ) : ?>
            <input type="hidden" name="is_popup" value="1">
        <?php endif; ?>

        <div class="es-field es-field__es_user_email es-field--email ">
            <label for="es-field-es_user_email">
                <div class="es-field__label">Email</div>
                <input id="es-field-es_user_email" name="emu_user_email" class="es-field__input" required="required" type="email" value="">
                <p class="es-field__description">You'll use it to sign in, and we'll use it to contact you.</p>
            </label>
        </div>

        <div class="es-field es-field__es_user_password es-field--password ">
            <label for="es-field-es_user_password">
                <div class="es-field__label">Password</div>
                <div class="es-input__wrap">
                    <input id="es-field-es_user_password" name="emu_user_password" class="js-es-password-field es-field__input" required="required" minlength="8" type="password" value="">
                    <a href="#" class="es-toggle-pwd js-es-toggle-pwd"><span class="es-icon es-icon_eye"></span></a>
                </div>
                <p class="es-field__description"></p>
                <ul class="es-field__validate-list">
                    <li class="es-validate-item es-validate-item__contain">Can't contain the name or email address</li>
                    <li class="es-validate-item es-validate-item__length">At least 8 characters</li>
                    <li class="es-validate-item es-validate-item__char">Contains a number or symbol</li>
                </ul>
            </label>
        </div>

        <button type="submit" class="emu-btn emu-btn--primary emu-btn--signup"><?php _e( 'Sign up', 'es' ); ?></button>
        <?php do_action( 'emu_privacy_policy', 'sign_up_form' ); ?>
        <p class="sign-in-text"><?php _e( 'Already have an account? <a href="#" class="js-es-auth-item__switcher" data-auth-item="login-buttons">Log in</a>', 'es' ); ?></p>
    </form>
</div>
